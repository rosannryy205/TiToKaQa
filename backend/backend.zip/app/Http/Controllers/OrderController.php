<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Order_detail;
use App\Models\Order_topping;
use App\Models\User as ModelsUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Mail;
use App\Mail\Info_order;
use App\Mail\ReservationMail;
use App\Models\Food;
use App\Models\Food_topping;
use App\Models\Reservation_table;
use App\Models\Table;
use Carbon\Carbon;

Carbon::setLocale('vi');
date_default_timezone_set('Asia/Ho_Chi_Minh');

use Exception;
use Illuminate\Support\Facades\Log;

class OrderController extends Controller
{
    //đặt bàn
    public function reservation(Request $request)
    {
        try {
            $data = $request->validate([
                'user_id' => 'nullable|numeric',
                'guest_name' => 'required|max:255',
                'guest_phone' => 'digits:10',
                'guest_email' => 'required|email',
                'guest_count' => 'required|integer|min:2',
                'reservations_time' => 'required|date',
                'note' => 'nullable|string',
                'deposit_amount' => 'nullable|numeric|min:0',
                'expiration_time' => 'required|date',
                'total_price' => 'required|numeric',
                'order_details' => 'nullable|array',
            ], [
                'guest_name.required' => 'Vui lòng nhập họ tên.',
                'guest_count.required' => 'Vui lòng nhập số lượng khách nhận bàn.',
                'guest_count.min' => 'Số lượng khách nhận bàn phải từ 2 trở lên.',
                'guest_email.required' => 'Vui lòng nhập email.',
                'guest_email.email' => 'Email không đúng định dạng.',
                'guest_phone.required' => 'Vui lòng nhập số điện thoại.',
                'guest_phone.regex' => 'Số điện thoại không đúng định dạng.',
                'guest_phone.digits' => 'Số điện thoại không đúng định dạng.',
                'reservations_time.required' => 'Vui lòng nhập ngày nhận bàn.',
            ]);

            $order = Order::create([
                'user_id' => $data['user_id'] ?? null,
                'guest_name' => $data['guest_name'],
                'guest_phone' => $data['guest_phone'],
                'guest_email' => $data['guest_email'],
                'guest_count' => $data['guest_count'],
                'reservations_time' => $data['reservations_time'],
                'note' => $data['note'] ?? null,
                'deposit_amount' => $data['deposit_amount'] ?? 0,
                'expiration_time' => $data['expiration_time'],
                'total_price' => $data['total_price'],
            ]);

            if (!empty($data['order_details'])) {
                foreach ($data['order_details'] as $item) {
                    $orderDetail = Order_detail::create([
                        'order_id' => $order->id,
                        'food_id' => $item['food_id'] ?? null,
                        'combo_id' => $item['combo_id'] ?? null,
                        'quantity' => $item['quantity'],
                        'price' => $item['price'],
                        'type' => $item['type'],
                    ]);

                    if (!empty($item['toppings'])) {
                        foreach ($item['toppings'] as $topping) {
                            Order_topping::create([
                                'order_detail_id' => $orderDetail->id,
                                'food_toppings_id' => $topping['food_toppings_id'],
                                'price' => $topping['price']
                            ]);
                        }
                    }
                }
            }

            $orderDetailsWithNames = [];
            if (!empty($data['order_details'])) {
                foreach ($data['order_details'] as $item) {
                    $name = null;

                    if ($item['type'] === 'food' && !empty($item['food_id'])) {
                        $food = Food::find($item['food_id']);
                        $name = $food?->name ?? 'Món ăn không tồn tại';
                    }

                    // lấy topping nếu có
                    $toppingsWithNames = [];
                    if (!empty($item['toppings'])) {
                        foreach ($item['toppings'] as $topping) {
                            $foodToppingModel = Food_topping::find($topping['food_toppings_id']);
                            $toppingModel = $foodToppingModel?->toppings; // lấy từ quan hệ

                            $toppingsWithNames[] = [
                                'name' => $toppingModel?->name ?? 'Topping không tồn tại',
                                'price' => $topping['price']
                            ];
                        }
                    }
                    $orderDetailsWithNames[] = [
                        'name' => $name,
                        'quantity' => $item['quantity'],
                        'price' => $item['price'],
                        'type' => $item['type'],
                        'toppings' => $toppingsWithNames,
                    ];
                }
            }

            $mailData = [
                'order_id' => $order->id,
                'guest_name' => $data['guest_name'],
                'guest_email' => $data['guest_email'],
                'guest_phone' => $data['guest_phone'],
                'guest_count' => $data['guest_count'],
                'reservations_time' => $data['reservations_time'],
                'total_price' => $data['total_price'],
                'note' => $data['note'] ?? null,
                'order_details' => $orderDetailsWithNames,
            ];

            // // Gửi email xác nhận đặt bàn
            // $emailTo = $mailData['guest_email'];
            // Mail::to($emailTo)->send(new ReservationMail($mailData));

            return response()->json([
                'status' => true,
                'message' => 'Đặt bàn thành công',
                'order_id' => $order->id
            ], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'error' => $e->getMessage()], 500);
        }
    }


    public function getInfoReservation(Request $request)
    {
        $value = $request->query('value');
        $type = $request->query('type');

        // Lấy đơn đặt bàn
        if ($type === 'user') {
            $reservation = Order::with([
                'details.foods',
                'details.toppings.food_toppings.toppings',
                'tables'
            ])->where('user_id', $value)->orderBy('id', 'desc')->first();
        } else {
            $reservation = Order::with([
                'details.foods',
                'details.toppings.food_toppings.toppings',
                'tables'
            ])->find($value);
        }

        if (!$reservation) {
            return response()->json([
                'status' => false,
                'mess' => 'Không tìm thấy đơn đặt bàn.',
            ], 404);
        }

        // Danh sách món ăn + topping
        $details = $reservation->details->map(function ($detail) {
            return [
                'id' => $detail->id,
                'food_id' => $detail->food_id,
                'food_name' => $detail->foods->name ?? null,
                'quantity' => $detail->quantity,
                'price' => $detail->price,
                'image' => $detail->foods->image ?? null,
                'type' => $detail->type,
                'toppings' => $detail->toppings->map(function ($toppings) {
                    return [
                        'food_toppings_id' => $toppings->food_toppings_id,
                        'topping_name' => $toppings->food_toppings->toppings->name ?? null,
                        'price' => $toppings->price
                    ];
                })
            ];
        });

        // // Thông tin bàn đã xếp
        $tables = $reservation->tables->map(function ($table) {
            return [
                'table_id' => $table->id,
                'table_number' => $table->table_number,
                'assigned_time' => $table->pivot->assigned_time,
                'reserved_from' => $table->pivot->reserved_from,
                'reserved_to' => $table->pivot->reserved_to,
            ];
        });

        return response()->json([
            'status' => true,
            'mess' => 'Lấy thông tin thành công',
            'info' => [
                'id' => $reservation->id,
                'user_id' => $reservation->user_id,
                'discount_id' => $reservation->discount_id,
                'order_time' => $reservation->order_time,
                'order_status' => $reservation->order_status,
                'total_price' => $reservation->total_price,
                'comment' => $reservation->comment,
                'review_time' => $reservation->review_time,
                'rating' => $reservation->rating,
                'guest_name' => $reservation->guest_name,
                'guest_phone' => $reservation->guest_phone,
                'guest_email' => $reservation->guest_email,
                'guest_address' => $reservation->guest_address,
                'guest_count' => $reservation->guest_count,
                'note' => $reservation->note,
                'deposit_amount' => $reservation->deposit_amount,
                'check_in_time' => $reservation->check_in_time,
                'reservations_time' => $reservation->reservations_time,
                'expiration_time' => $reservation->expiration_time,
                'reservation_status' => $reservation->reservation_status,
                'details' => $details,
                'tables' => $tables,
            ]
        ], 200);
    }


    public function getInfoOrderByUser(Request $request)
    {
        $userId = $request->id;

        $orders = Order::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'orders' => $orders
        ]);
    }

    public function cancelOrder(Request $request)
    {
        $order = Order::find($request->id);

        if (!$order) {
            return response()->json(['message' => 'Không tìm thấy đơn hàng.'], 404);
        }

        $order->order_status = 'Đã hủy';
        $order->reservation_status = 'Đã hủy';
        $order->save();

        return response()->json(['message' => 'Đơn hàng đã được hủy thành công.']);
    }

    public function updateAddressForOrder(Request $request, $id)
    {
        try {
            $request->validate([
                'guest_address' => 'required|string|max:255',
            ]);
            $order = Order::find($id);
            if (!$order) {
                return response()->json(['message' => 'Không tìm thấy đơn hàng.'], 404);
            }
            $order->guest_address = $request->guest_address;
            if ($order->save()) {
                return response()->json(['message' => 'Địa chỉ đã được thay đổi thành công.']);
            } else {
                return response()->json(['message' => 'Đã xảy ra lỗi khi cập nhật địa chỉ.'], 500);
            }
        } catch (ValidationException $th) {
            return response()->json([
                'status' => false,
                'errors' => $th->errors()
            ], 422);
        }
    }

    public function getTables()
    {
        $tables = Table::all();
        return $tables;
    }

    public function getAvailableTables(Request $request)
    {
        $from = $request->input('reserved_from');
        $to = $request->input('reserved_to');

        $freeTables = Table::where('status', 'Bàn trống')->get();

        $conflictingTableIds = Reservation_table::where(function ($query) use ($from, $to) {
            $query->where(function ($q) use ($from, $to) {
                $q->where('reserved_from', '<', $to)
                    ->where('reserved_to', '>', $from);
            });
        })->pluck('table_id')->toArray();

        $nonConflictingTables = Table::whereNotIn('id', $conflictingTableIds)
            ->where('status', '!=', 'Bàn trống')
            ->get();

        $availableTables = $freeTables->merge($nonConflictingTables);

        return response()->json([
            'status' => true,
            'tables' => $availableTables
        ]);
    }



    public function getOrderOfTable()
    {
        $orders = Order::with('tables')->get();

        $orderWithTables = $orders->map(function ($order) {
            return [
                'order_id' => $order->id,
                'user_id' => $order->user_id,
                'order_status' => $order->order_status,
                'total_price' => $order->total_price,
                'guest_name' => $order->guest_name,
                'guest_phone' => $order->guest_phone,
                'guest_email' => $order->guest_email,
                'guest_address' => $order->guest_address,
                'guest_count' => $order->guest_count,
                'comment' => $order->comment,
                'reservation_status' => $order->reservation_status,
                'reservations_time' => $order->reservations_time,
                'check_in_time' => $order->check_in_time,
                'table_numbers' => $order->tables->pluck('table_number')->toArray(),
            ];
        });

        return response()->json([
            'status' => true,
            'data' => $orderWithTables,
        ]);
    }




    public function setUpTable(Request $request)
    {
        try {
            $data = $request->validate([
                'order_id' => 'required|numeric',
                'table_ids' => 'required|array',
                'table_ids.*' => 'numeric',
                'assigned_time' => 'required|date',
                'reserved_from' => 'required|date',
                'reserved_to' => 'nullable|date',
            ], [
                'table_ids.required' => 'Bạn chưa xếp bàn cho đơn hàng này.',
            ]);

            $createdTables = [];

            foreach ($data['table_ids'] as $table_id) {
                $existing = Reservation_table::where('order_id', $data['order_id'])
                    ->where('table_id', $table_id)
                    ->exists();

                if ($existing) {
                    return response()->json([
                        'status' => false,
                        'message' => "Bàn số {$table_id} đã được chọn cho đơn hàng này rồi."
                    ], 400);
                }

                $reservation = Reservation_table::create([
                    'order_id' => $data['order_id'],
                    'table_id' => $table_id,
                    'assigned_time' => $data['assigned_time'] ?? null,
                    'reserved_from' => $data['reserved_from'],
                    'reserved_to' => $data['reserved_to'],
                ]);
                $createdTables[] = $reservation;

                Table::where('id', $table_id)->update([
                    'status' => 'Đã đặt trước'
                ]);
            }


            Order::where('id', $data['order_id'])->update([
                'reservation_status' => 'Đã xếp bàn'
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Xếp bàn thành công và trạng thái bàn đã thay đổi thành "Đã đặt trước".',
            ]);
        } catch (ValidationException $th) {
            return response()->json([
                'status' => false,
                'errors' => $th->errors()
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function getAllFoodsWithToppings()
    {
        try {
            $foods = Food::with('toppings')->get();
            return response()->json($foods);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Lỗi khi lấy danh sách món ăn và topping', 'error' => $e->getMessage()], 500);
        }
    }

    public function updateStatus(Request $request)
    {
        $order = Order::find($request->id);

        if (!$order) {
            return response()->json(['message' => 'Không tìm thấy đơn hàng.'], 404);
        }
        $order->reservation_status = $request->reservation_status;
        if ($request->reservation_status === 'Khách Đã Đến') {
            $order->check_in_time = Carbon::now();
        }
        if (in_array($request->reservation_status, ['Đã hủy', 'Hoàn Thành'])) {
            foreach ($order->tables as $table) {
                $table->status = 'Bàn trống';
                $table->save();
            }
        }
        $order->save();
        return response()->json(['message' => 'Đơn hàng đã được cập nhật thành công.']);
    }



    public function autoCancelOrders()
    {
        $now = now();

        $orders = Order::whereNull('check_in_time')
            ->where('expiration_time', '<', $now)
            ->where('reservation_status', '!=', 'Đã huỷ')
            ->get();

        foreach ($orders as $order) {
            $order->reservation_status = 'Đã huỷ';
            $order->save();
        }

        return response()->json([
            'message' => 'Đã huỷ ' . $orders->count() . ' đơn quá hạn chưa check-in.',
        ]);
    }
}
